/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50619
Source Host           : localhost:3306
Source Database       : qunxian

Target Server Type    : MYSQL
Target Server Version : 50619
File Encoding         : 65001

Date: 2016-04-29 16:12:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin_channels
-- ----------------------------
DROP TABLE IF EXISTS `admin_channels`;
CREATE TABLE `admin_channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `typo` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `short_title` varchar(255) DEFAULT NULL,
  `properties` varchar(255) DEFAULT NULL,
  `default_url` varchar(255) DEFAULT NULL,
  `tmp_index` varchar(255) DEFAULT NULL,
  `tmp_list` varchar(255) DEFAULT NULL,
  `tmp_detail` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_admin_channels_on_short_title` (`short_title`),
  KEY `index_admin_channels_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_channels
-- ----------------------------
INSERT INTO `admin_channels` VALUES ('1', null, null, 'article', '首页', 'index', '1', null, 'temp_index.html', null, 'temp_detail.html', '首页', '欢迎使用RainCMS, 成都探码科技有限公司出品！', null, '2016-04-21 13:27:54', '2016-04-21 13:27:54', null);
INSERT INTO `admin_channels` VALUES ('3', '3', null, 'article', '群仙闽睿', 'qun-xian-mi', null, null, 'temp_index.html', null, 'temp_index.html', '', '', '', '2016-04-29 07:51:24', '2016-04-29 07:51:24', '');
INSERT INTO `admin_channels` VALUES ('4', '3', null, 'article', '新闻中心', 'xin-wen-zho', null, null, '_foot.html', null, '_foot.html', '', '', '', '2016-04-29 07:52:01', '2016-04-29 07:52:01', '');
INSERT INTO `admin_channels` VALUES ('5', '3', null, 'article', '闽睿红木', 'min-rui-hon', null, null, '_foot.html', null, '_foot.html', '', '', '', '2016-04-29 07:52:18', '2016-04-29 07:52:18', '');
INSERT INTO `admin_channels` VALUES ('6', '3', null, 'article', ' 德华陶瓷', '-de-hua-tao', null, null, '_head.html', null, '_footer.html', '', '', '', '2016-04-29 07:52:32', '2016-04-29 07:52:32', '');
INSERT INTO `admin_channels` VALUES ('7', '3', null, 'article', '八马茶叶', 'ba-ma-cha-y', null, null, '_foot.html', null, '_footer.html', '', '', '', '2016-04-29 07:52:54', '2016-04-29 07:52:54', '');
INSERT INTO `admin_channels` VALUES ('8', '3', null, 'article', '珍宝阁 ', 'zhen-bao-ge', null, null, '_foot.html', null, '_foot.html', '', '', '', '2016-04-29 07:53:08', '2016-04-29 07:53:08', '');
INSERT INTO `admin_channels` VALUES ('9', '3', null, 'article', '私人定制', 'si-ren-ding', null, null, '_footer.html', null, '_footer.html', '', '', '', '2016-04-29 07:53:21', '2016-04-29 07:53:21', '');
INSERT INTO `admin_channels` VALUES ('10', '3', null, 'article', '招商加盟 ', 'zhao-shang', null, null, '_foot.html', null, '_foot.html', '', '', '', '2016-04-29 07:53:35', '2016-04-29 07:53:35', '');
INSERT INTO `admin_channels` VALUES ('11', '3', null, 'article', ' 联系我们', '-lian-xi-wo', null, null, '_footer.html', null, '_foot.html', '', '', '', '2016-04-29 07:53:58', '2016-04-29 07:53:58', '');

-- ----------------------------
-- Table structure for admin_comments
-- ----------------------------
DROP TABLE IF EXISTS `admin_comments`;
CREATE TABLE `admin_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `qq` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `hobby` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `content2` text COLLATE utf8_unicode_ci,
  `content3` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `branch` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of admin_comments
-- ----------------------------

-- ----------------------------
-- Table structure for admin_forages
-- ----------------------------
DROP TABLE IF EXISTS `admin_forages`;
CREATE TABLE `admin_forages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of admin_forages
-- ----------------------------

-- ----------------------------
-- Table structure for admin_keystores
-- ----------------------------
DROP TABLE IF EXISTS `admin_keystores`;
CREATE TABLE `admin_keystores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_admin_keystores_on_key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_keystores
-- ----------------------------
INSERT INTO `admin_keystores` VALUES ('1', 'templete', 'qunxian', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('2', 'site_name', 'Rain CMS', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('3', 'contact_name', '探码科技', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('4', 'contact_qq', '77632132', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('5', 'contact_wechat', 'xuejiang_song', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('6', 'contact_weibo', 'tanmer', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('7', 'weibo_url', 'http://www.weibo.com/tanmer', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('8', 'contact_mobile', '18080810818', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('9', 'contact_email', 'app@mesbo.cn', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `admin_keystores` VALUES ('10', 'firm_name', '成都探码科技有限公司', null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');

-- ----------------------------
-- Table structure for admin_pages
-- ----------------------------
DROP TABLE IF EXISTS `admin_pages`;
CREATE TABLE `admin_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `short_title` varchar(255) DEFAULT NULL,
  `properties` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `content` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `discount` decimal(10,0) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `external_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_admin_pages_on_short_title` (`short_title`),
  KEY `index_admin_pages_on_user_id` (`user_id`),
  KEY `index_admin_pages_on_channel_id` (`channel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_pages
-- ----------------------------
INSERT INTO `admin_pages` VALUES ('1', '3', '3', '公司简介', 'gong-si-jia', '', '', '', '', '<p><a href=\"http://localhost:3000/#\">公司简介</a></p>\r\n', '2016-04-29 07:57:20', '2016-04-29 07:57:20', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('2', '3', '3', '品牌介绍', 'pin-pai-jie', '', '', '', '', '<p><a href=\"http://localhost:3000/#\">品牌介绍</a></p>\r\n', '2016-04-29 07:57:59', '2016-04-29 07:58:55', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('3', '3', '3', '品牌理念', 'pin-pai-li', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 07:58:28', '2016-04-29 07:58:28', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('4', '3', '3', '企业视频', 'qi-ye-shi-p', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 07:58:43', '2016-04-29 07:58:43', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('5', '3', '4', '公司新闻', 'gong-si-xin', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 07:59:25', '2016-04-29 07:59:25', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('6', '3', '4', '行业新闻', 'xing-ye-xin', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 07:59:42', '2016-04-29 08:07:06', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('7', '3', '5', '红木展示', 'hong-mu-zha', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:07:52', '2016-04-29 08:07:52', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('8', '3', '5', '红木文化', 'hong-mu-wen', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:08:14', '2016-04-29 08:08:14', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('9', '3', '5', '红木常识', 'hong-mu-cha', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:08:37', '2016-04-29 08:08:37', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('10', '3', '5', '红木保养', 'hong-mu-bao', '', '', '', '', '<p>去</p>\r\n', '2016-04-29 08:08:56', '2016-04-29 08:08:56', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('11', '3', '6', '陶瓷展示', 'tao-ci-zhan', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:09:11', '2016-04-29 08:09:11', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('12', '3', '6', '陶瓷文化', 'tao-ci-wen', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:09:26', '2016-04-29 08:09:26', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('13', '3', '6', '陶瓷常识', 'tao-ci-chan', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:09:41', '2016-04-29 08:09:41', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('14', '3', '6', '陶瓷保养', 'tao-ci-bao', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:09:56', '2016-04-29 08:09:56', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('15', '3', '7', '茶叶展示', 'cha-ye-zhan', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:10:14', '2016-04-29 08:10:14', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('16', '3', '7', '茶叶文化', 'cha-ye-wen', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:10:27', '2016-04-29 08:10:27', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('17', '3', '7', '茶叶常识', 'cha-ye-chan', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:10:40', '2016-04-29 08:10:40', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('18', '3', '7', '茶叶保养', 'cha-ye-bao', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:10:57', '2016-04-29 08:10:57', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('19', '3', '8', '珍宝展示', 'zhen-bao-zh', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:11:17', '2016-04-29 08:11:17', null, null, '个', null, '');
INSERT INTO `admin_pages` VALUES ('20', '3', '9', '专属定制', 'zhuan-shu-d', '', '', '', '', '<p>1</p>\r\n', '2016-04-29 08:11:31', '2016-04-29 08:11:31', null, null, '个', null, '');

-- ----------------------------
-- Table structure for admin_properties
-- ----------------------------
DROP TABLE IF EXISTS `admin_properties`;
CREATE TABLE `admin_properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_admin_properties_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of admin_properties
-- ----------------------------
INSERT INTO `admin_properties` VALUES ('6', '加粗');
INSERT INTO `admin_properties` VALUES ('7', '图片');
INSERT INTO `admin_properties` VALUES ('1', '头条');
INSERT INTO `admin_properties` VALUES ('3', '幻灯');
INSERT INTO `admin_properties` VALUES ('4', '底部');
INSERT INTO `admin_properties` VALUES ('2', '推荐');
INSERT INTO `admin_properties` VALUES ('5', '滚动');
INSERT INTO `admin_properties` VALUES ('8', '跳转');

-- ----------------------------
-- Table structure for ckeditor_assets
-- ----------------------------
DROP TABLE IF EXISTS `ckeditor_assets`;
CREATE TABLE `ckeditor_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_file_name` varchar(255) NOT NULL,
  `data_content_type` varchar(255) DEFAULT NULL,
  `data_file_size` int(11) DEFAULT NULL,
  `assetable_id` int(11) DEFAULT NULL,
  `assetable_type` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ckeditor_assetable_type` (`assetable_type`,`type`,`assetable_id`),
  KEY `idx_ckeditor_assetable` (`assetable_type`,`assetable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ckeditor_assets
-- ----------------------------

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `resource_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_roles_on_name` (`name`),
  KEY `index_roles_on_name_and_resource_type_and_resource_id` (`name`,`resource_type`,`resource_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES ('1', 'admin', null, null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `roles` VALUES ('2', 'user', null, null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');
INSERT INTO `roles` VALUES ('3', 'VIP', null, null, '2016-04-21 13:27:53', '2016-04-21 13:27:53');

-- ----------------------------
-- Table structure for schema_migrations
-- ----------------------------
DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of schema_migrations
-- ----------------------------
INSERT INTO `schema_migrations` VALUES ('20131110064853');
INSERT INTO `schema_migrations` VALUES ('20131110064856');
INSERT INTO `schema_migrations` VALUES ('20131110064858');
INSERT INTO `schema_migrations` VALUES ('20131110064904');
INSERT INTO `schema_migrations` VALUES ('20131110121718');
INSERT INTO `schema_migrations` VALUES ('20131110122121');
INSERT INTO `schema_migrations` VALUES ('20131110122529');
INSERT INTO `schema_migrations` VALUES ('20131110203517');
INSERT INTO `schema_migrations` VALUES ('20131112092735');
INSERT INTO `schema_migrations` VALUES ('20140124050217');
INSERT INTO `schema_migrations` VALUES ('20140625045401');
INSERT INTO `schema_migrations` VALUES ('20140829182312');
INSERT INTO `schema_migrations` VALUES ('20140913122955');
INSERT INTO `schema_migrations` VALUES ('20150125160854');
INSERT INTO `schema_migrations` VALUES ('20150408142927');
INSERT INTO `schema_migrations` VALUES ('20150424064655');
INSERT INTO `schema_migrations` VALUES ('20150424064656');
INSERT INTO `schema_migrations` VALUES ('20150424064657');
INSERT INTO `schema_migrations` VALUES ('20150424064658');
INSERT INTO `schema_migrations` VALUES ('20150725155624');
INSERT INTO `schema_migrations` VALUES ('20150807072714');

-- ----------------------------
-- Table structure for taggings
-- ----------------------------
DROP TABLE IF EXISTS `taggings`;
CREATE TABLE `taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `taggable_type` varchar(255) DEFAULT NULL,
  `tagger_id` int(11) DEFAULT NULL,
  `tagger_type` varchar(255) DEFAULT NULL,
  `context` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taggings_idx` (`tag_id`,`taggable_id`,`taggable_type`,`context`,`tagger_id`,`tagger_type`),
  KEY `index_taggings_on_taggable_id_and_taggable_type_and_context` (`taggable_id`,`taggable_type`,`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of taggings
-- ----------------------------

-- ----------------------------
-- Table structure for tags
-- ----------------------------
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `cate_id` int(11) DEFAULT NULL,
  `taggings_count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_tags_on_name` (`name`),
  KEY `index_tags_on_cate_id` (`cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tags
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `confirmation_sent_at` datetime DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('3', 'mi@tanmer.com', '$2a$10$g6NGxCLXArwffJbZoOk62uIhHjnCYjBG47rvN188nJyo/bGC/HrIe', null, null, null, '1', '2016-04-29 07:48:09', '2016-04-29 07:48:09', '::1', '::1', '2016-04-29 07:46:15', '2016-04-29 07:48:09', 'mi2', null, null, null, null);

-- ----------------------------
-- Table structure for users_roles
-- ----------------------------
DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE `users_roles` (
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  KEY `index_users_roles_on_user_id_and_role_id` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of users_roles
-- ----------------------------
INSERT INTO `users_roles` VALUES ('3', '1');
